/*******************************************************************************
* Copyright (C) 2011, FuseSource Corp.  All rights reserved.
*
*     http://fusesource.com
*
* The software in this package is published under the terms of the
* CDDL license a copy of which has been included with this distribution
* in the license.txt file.
*******************************************************************************/
#ifdef NATIVE_STATS
extern int JNI_nativeFunctionCount;
extern int JNI_nativeFunctionCallCount[];
extern char* JNI_nativeFunctionNames[];
#define JNI_NATIVE_ENTER(env, that, func) JNI_nativeFunctionCallCount[func]++;
#define JNI_NATIVE_EXIT(env, that, func) 
#else
#ifndef JNI_NATIVE_ENTER
#define JNI_NATIVE_ENTER(env, that, func) 
#endif
#ifndef JNI_NATIVE_EXIT
#define JNI_NATIVE_EXIT(env, that, func) 
#endif
#endif

typedef enum {
	JNI_buffer_1copy__JJ_3BJJ_FUNC,
	JNI_buffer_1copy___3BJJJJ_FUNC,
	JNI_errno_FUNC,
	JNI_free_FUNC,
	JNI_init_FUNC,
	JNI_malloc_FUNC,
	JNI_mdb_1cmp_FUNC,
	JNI_mdb_1cursor_1close_FUNC,
	JNI_mdb_1cursor_1count_FUNC,
	JNI_mdb_1cursor_1dbi_FUNC,
	JNI_mdb_1cursor_1del_FUNC,
	JNI_mdb_1cursor_1get_1address_FUNC,
	JNI_mdb_1cursor_1get_1copy_1in_FUNC,
	JNI_mdb_1cursor_1get_1no_1copy_1in_FUNC,
	JNI_mdb_1cursor_1open_FUNC,
	JNI_mdb_1cursor_1put_FUNC,
	JNI_mdb_1cursor_1put_1address_FUNC,
	JNI_mdb_1cursor_1renew_FUNC,
	JNI_mdb_1cursor_1txn_FUNC,
	JNI_mdb_1dbi_1close_FUNC,
	JNI_mdb_1dbi_1open_FUNC,
	JNI_mdb_1dcmp_FUNC,
	JNI_mdb_1del_FUNC,
	JNI_mdb_1drop_FUNC,
	JNI_mdb_1env_1close_FUNC,
	JNI_mdb_1env_1copy_FUNC,
	JNI_mdb_1env_1copy2_FUNC,
	JNI_mdb_1env_1create_FUNC,
	JNI_mdb_1env_1get_1flags_FUNC,
	JNI_mdb_1env_1get_1maxkeysize_FUNC,
	JNI_mdb_1env_1get_1maxreaders_FUNC,
	JNI_mdb_1env_1get_1path_FUNC,
	JNI_mdb_1env_1info_FUNC,
	JNI_mdb_1env_1open_FUNC,
	JNI_mdb_1env_1set_1flags_FUNC,
	JNI_mdb_1env_1set_1mapsize_FUNC,
	JNI_mdb_1env_1set_1maxdbs_FUNC,
	JNI_mdb_1env_1set_1maxreaders_FUNC,
	JNI_mdb_1env_1stat_FUNC,
	JNI_mdb_1env_1sync_FUNC,
	JNI_mdb_1get_FUNC,
	JNI_mdb_1get_1address_FUNC,
	JNI_mdb_1put_FUNC,
	JNI_mdb_1put_1address_FUNC,
	JNI_mdb_1reader_1check_FUNC,
	JNI_mdb_1set_1compare_FUNC,
	JNI_mdb_1set_1dupsort_FUNC,
	JNI_mdb_1stat_FUNC,
	JNI_mdb_1strerror_FUNC,
	JNI_mdb_1txn_1abort_FUNC,
	JNI_mdb_1txn_1begin_FUNC,
	JNI_mdb_1txn_1commit_FUNC,
	JNI_mdb_1txn_1id_FUNC,
	JNI_mdb_1txn_1renew_FUNC,
	JNI_mdb_1txn_1reset_FUNC,
	JNI_strerror_FUNC,
	JNI_strlen_FUNC,
} JNI_FUNCS;
