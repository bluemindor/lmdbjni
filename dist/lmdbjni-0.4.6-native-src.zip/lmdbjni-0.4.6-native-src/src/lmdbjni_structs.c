/*******************************************************************************
* Copyright (C) 2011, FuseSource Corp.  All rights reserved.
*
*     http://fusesource.com
*
* The software in this package is published under the terms of the
* CDDL license a copy of which has been included with this distribution
* in the license.txt file.
*******************************************************************************/
#include "lmdbjni.h"
#include "hawtjni.h"
#include "lmdbjni_structs.h"

typedef struct MDB_envinfo_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID me_mapaddr, me_mapsize, me_last_pgno, me_last_txnid, me_maxreaders, me_numreaders;
} MDB_envinfo_FID_CACHE;

MDB_envinfo_FID_CACHE MDB_envinfoFc;

void cacheMDB_envinfoFields(JNIEnv *env, jobject lpObject)
{
	if (MDB_envinfoFc.cached) return;
	MDB_envinfoFc.clazz = (*env)->GetObjectClass(env, lpObject);
	MDB_envinfoFc.me_mapaddr = (*env)->GetFieldID(env, MDB_envinfoFc.clazz, "me_mapaddr", "J");
	MDB_envinfoFc.me_mapsize = (*env)->GetFieldID(env, MDB_envinfoFc.clazz, "me_mapsize", "J");
	MDB_envinfoFc.me_last_pgno = (*env)->GetFieldID(env, MDB_envinfoFc.clazz, "me_last_pgno", "J");
	MDB_envinfoFc.me_last_txnid = (*env)->GetFieldID(env, MDB_envinfoFc.clazz, "me_last_txnid", "J");
	MDB_envinfoFc.me_maxreaders = (*env)->GetFieldID(env, MDB_envinfoFc.clazz, "me_maxreaders", "J");
	MDB_envinfoFc.me_numreaders = (*env)->GetFieldID(env, MDB_envinfoFc.clazz, "me_numreaders", "J");
	hawtjni_w_barrier();
	MDB_envinfoFc.cached = 1;
}

MDB_envinfo *getMDB_envinfoFields(JNIEnv *env, jobject lpObject, MDB_envinfo *lpStruct)
{
	if (!MDB_envinfoFc.cached) cacheMDB_envinfoFields(env, lpObject);
	lpStruct->me_mapaddr = (void *)(intptr_t)(*env)->GetLongField(env, lpObject, MDB_envinfoFc.me_mapaddr);
	lpStruct->me_mapsize = (size_t)(*env)->GetLongField(env, lpObject, MDB_envinfoFc.me_mapsize);
	lpStruct->me_last_pgno = (size_t)(*env)->GetLongField(env, lpObject, MDB_envinfoFc.me_last_pgno);
	lpStruct->me_last_txnid = (size_t)(*env)->GetLongField(env, lpObject, MDB_envinfoFc.me_last_txnid);
	lpStruct->me_maxreaders = (unsigned int)(*env)->GetLongField(env, lpObject, MDB_envinfoFc.me_maxreaders);
	lpStruct->me_numreaders = (unsigned int)(*env)->GetLongField(env, lpObject, MDB_envinfoFc.me_numreaders);
	return lpStruct;
}

void setMDB_envinfoFields(JNIEnv *env, jobject lpObject, MDB_envinfo *lpStruct)
{
	if (!MDB_envinfoFc.cached) cacheMDB_envinfoFields(env, lpObject);
	(*env)->SetLongField(env, lpObject, MDB_envinfoFc.me_mapaddr, (jlong)(intptr_t)lpStruct->me_mapaddr);
	(*env)->SetLongField(env, lpObject, MDB_envinfoFc.me_mapsize, (jlong)lpStruct->me_mapsize);
	(*env)->SetLongField(env, lpObject, MDB_envinfoFc.me_last_pgno, (jlong)lpStruct->me_last_pgno);
	(*env)->SetLongField(env, lpObject, MDB_envinfoFc.me_last_txnid, (jlong)lpStruct->me_last_txnid);
	(*env)->SetLongField(env, lpObject, MDB_envinfoFc.me_maxreaders, (jlong)lpStruct->me_maxreaders);
	(*env)->SetLongField(env, lpObject, MDB_envinfoFc.me_numreaders, (jlong)lpStruct->me_numreaders);
}

typedef struct MDB_stat_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID ms_psize, ms_depth, ms_branch_pages, ms_leaf_pages, ms_overflow_pages, ms_entries;
} MDB_stat_FID_CACHE;

MDB_stat_FID_CACHE MDB_statFc;

void cacheMDB_statFields(JNIEnv *env, jobject lpObject)
{
	if (MDB_statFc.cached) return;
	MDB_statFc.clazz = (*env)->GetObjectClass(env, lpObject);
	MDB_statFc.ms_psize = (*env)->GetFieldID(env, MDB_statFc.clazz, "ms_psize", "J");
	MDB_statFc.ms_depth = (*env)->GetFieldID(env, MDB_statFc.clazz, "ms_depth", "J");
	MDB_statFc.ms_branch_pages = (*env)->GetFieldID(env, MDB_statFc.clazz, "ms_branch_pages", "J");
	MDB_statFc.ms_leaf_pages = (*env)->GetFieldID(env, MDB_statFc.clazz, "ms_leaf_pages", "J");
	MDB_statFc.ms_overflow_pages = (*env)->GetFieldID(env, MDB_statFc.clazz, "ms_overflow_pages", "J");
	MDB_statFc.ms_entries = (*env)->GetFieldID(env, MDB_statFc.clazz, "ms_entries", "J");
	hawtjni_w_barrier();
	MDB_statFc.cached = 1;
}

MDB_stat *getMDB_statFields(JNIEnv *env, jobject lpObject, MDB_stat *lpStruct)
{
	if (!MDB_statFc.cached) cacheMDB_statFields(env, lpObject);
	lpStruct->ms_psize = (unsigned int)(*env)->GetLongField(env, lpObject, MDB_statFc.ms_psize);
	lpStruct->ms_depth = (unsigned int)(*env)->GetLongField(env, lpObject, MDB_statFc.ms_depth);
	lpStruct->ms_branch_pages = (size_t)(*env)->GetLongField(env, lpObject, MDB_statFc.ms_branch_pages);
	lpStruct->ms_leaf_pages = (size_t)(*env)->GetLongField(env, lpObject, MDB_statFc.ms_leaf_pages);
	lpStruct->ms_overflow_pages = (size_t)(*env)->GetLongField(env, lpObject, MDB_statFc.ms_overflow_pages);
	lpStruct->ms_entries = (size_t)(*env)->GetLongField(env, lpObject, MDB_statFc.ms_entries);
	return lpStruct;
}

void setMDB_statFields(JNIEnv *env, jobject lpObject, MDB_stat *lpStruct)
{
	if (!MDB_statFc.cached) cacheMDB_statFields(env, lpObject);
	(*env)->SetLongField(env, lpObject, MDB_statFc.ms_psize, (jlong)lpStruct->ms_psize);
	(*env)->SetLongField(env, lpObject, MDB_statFc.ms_depth, (jlong)lpStruct->ms_depth);
	(*env)->SetLongField(env, lpObject, MDB_statFc.ms_branch_pages, (jlong)lpStruct->ms_branch_pages);
	(*env)->SetLongField(env, lpObject, MDB_statFc.ms_leaf_pages, (jlong)lpStruct->ms_leaf_pages);
	(*env)->SetLongField(env, lpObject, MDB_statFc.ms_overflow_pages, (jlong)lpStruct->ms_overflow_pages);
	(*env)->SetLongField(env, lpObject, MDB_statFc.ms_entries, (jlong)lpStruct->ms_entries);
}

typedef struct MDB_val_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID mv_size, mv_data;
} MDB_val_FID_CACHE;

MDB_val_FID_CACHE MDB_valFc;

void cacheMDB_valFields(JNIEnv *env, jobject lpObject)
{
	if (MDB_valFc.cached) return;
	MDB_valFc.clazz = (*env)->GetObjectClass(env, lpObject);
	MDB_valFc.mv_size = (*env)->GetFieldID(env, MDB_valFc.clazz, "mv_size", "J");
	MDB_valFc.mv_data = (*env)->GetFieldID(env, MDB_valFc.clazz, "mv_data", "J");
	hawtjni_w_barrier();
	MDB_valFc.cached = 1;
}

MDB_val *getMDB_valFields(JNIEnv *env, jobject lpObject, MDB_val *lpStruct)
{
	if (!MDB_valFc.cached) cacheMDB_valFields(env, lpObject);
	lpStruct->mv_size = (size_t)(*env)->GetLongField(env, lpObject, MDB_valFc.mv_size);
	lpStruct->mv_data = (void *)(intptr_t)(*env)->GetLongField(env, lpObject, MDB_valFc.mv_data);
	return lpStruct;
}

void setMDB_valFields(JNIEnv *env, jobject lpObject, MDB_val *lpStruct)
{
	if (!MDB_valFc.cached) cacheMDB_valFields(env, lpObject);
	(*env)->SetLongField(env, lpObject, MDB_valFc.mv_size, (jlong)lpStruct->mv_size);
	(*env)->SetLongField(env, lpObject, MDB_valFc.mv_data, (jlong)(intptr_t)lpStruct->mv_data);
}

