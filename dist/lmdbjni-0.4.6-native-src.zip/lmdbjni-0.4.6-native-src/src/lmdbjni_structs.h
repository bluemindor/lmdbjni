/*******************************************************************************
* Copyright (C) 2011, FuseSource Corp.  All rights reserved.
*
*     http://fusesource.com
*
* The software in this package is published under the terms of the
* CDDL license a copy of which has been included with this distribution
* in the license.txt file.
*******************************************************************************/
#include "lmdbjni.h"

void cacheMDB_envinfoFields(JNIEnv *env, jobject lpObject);
MDB_envinfo *getMDB_envinfoFields(JNIEnv *env, jobject lpObject, MDB_envinfo *lpStruct);
void setMDB_envinfoFields(JNIEnv *env, jobject lpObject, MDB_envinfo *lpStruct);

void cacheMDB_statFields(JNIEnv *env, jobject lpObject);
MDB_stat *getMDB_statFields(JNIEnv *env, jobject lpObject, MDB_stat *lpStruct);
void setMDB_statFields(JNIEnv *env, jobject lpObject, MDB_stat *lpStruct);

void cacheMDB_valFields(JNIEnv *env, jobject lpObject);
MDB_val *getMDB_valFields(JNIEnv *env, jobject lpObject, MDB_val *lpStruct);
void setMDB_valFields(JNIEnv *env, jobject lpObject, MDB_val *lpStruct);

