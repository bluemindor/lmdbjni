/*******************************************************************************
* Copyright (C) 2011, FuseSource Corp.  All rights reserved.
*
*     http://fusesource.com
*
* The software in this package is published under the terms of the
* CDDL license a copy of which has been included with this distribution
* in the license.txt file.
*******************************************************************************/
#include "hawtjni.h"
#include "lmdbjni_stats.h"

#ifdef NATIVE_STATS

int JNI_nativeFunctionCount = 57;
int JNI_nativeFunctionCallCount[57];
char * JNI_nativeFunctionNames[] = {
	"buffer_1copy__JJ_3BJJ",
	"buffer_1copy___3BJJJJ",
	"errno",
	"free",
	"init",
	"malloc",
	"mdb_1cmp",
	"mdb_1cursor_1close",
	"mdb_1cursor_1count",
	"mdb_1cursor_1dbi",
	"mdb_1cursor_1del",
	"mdb_1cursor_1get_1address",
	"mdb_1cursor_1get_1copy_1in",
	"mdb_1cursor_1get_1no_1copy_1in",
	"mdb_1cursor_1open",
	"mdb_1cursor_1put",
	"mdb_1cursor_1put_1address",
	"mdb_1cursor_1renew",
	"mdb_1cursor_1txn",
	"mdb_1dbi_1close",
	"mdb_1dbi_1open",
	"mdb_1dcmp",
	"mdb_1del",
	"mdb_1drop",
	"mdb_1env_1close",
	"mdb_1env_1copy",
	"mdb_1env_1copy2",
	"mdb_1env_1create",
	"mdb_1env_1get_1flags",
	"mdb_1env_1get_1maxkeysize",
	"mdb_1env_1get_1maxreaders",
	"mdb_1env_1get_1path",
	"mdb_1env_1info",
	"mdb_1env_1open",
	"mdb_1env_1set_1flags",
	"mdb_1env_1set_1mapsize",
	"mdb_1env_1set_1maxdbs",
	"mdb_1env_1set_1maxreaders",
	"mdb_1env_1stat",
	"mdb_1env_1sync",
	"mdb_1get",
	"mdb_1get_1address",
	"mdb_1put",
	"mdb_1put_1address",
	"mdb_1reader_1check",
	"mdb_1set_1compare",
	"mdb_1set_1dupsort",
	"mdb_1stat",
	"mdb_1strerror",
	"mdb_1txn_1abort",
	"mdb_1txn_1begin",
	"mdb_1txn_1commit",
	"mdb_1txn_1id",
	"mdb_1txn_1renew",
	"mdb_1txn_1reset",
	"strerror",
	"strlen",
};

#define STATS_NATIVE(func) Java_org_fusesource_hawtjni_runtime_NativeStats_##func

JNIEXPORT jint JNICALL STATS_NATIVE(JNI_1GetFunctionCount)
	(JNIEnv *env, jclass that)
{
	return JNI_nativeFunctionCount;
}

JNIEXPORT jstring JNICALL STATS_NATIVE(JNI_1GetFunctionName)
	(JNIEnv *env, jclass that, jint index)
{
	return (*env)->NewStringUTF(env, JNI_nativeFunctionNames[index]);
}

JNIEXPORT jint JNICALL STATS_NATIVE(JNI_1GetFunctionCallCount)
	(JNIEnv *env, jclass that, jint index)
{
	return JNI_nativeFunctionCallCount[index];
}

#endif
