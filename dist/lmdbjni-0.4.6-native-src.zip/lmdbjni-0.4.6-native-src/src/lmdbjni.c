/*******************************************************************************
* Copyright (C) 2011, FuseSource Corp.  All rights reserved.
*
*     http://fusesource.com
*
* The software in this package is published under the terms of the
* CDDL license a copy of which has been included with this distribution
* in the license.txt file.
*******************************************************************************/
#include "lmdbjni.h"
#include "hawtjni.h"
#include "lmdbjni_structs.h"
#include "lmdbjni_stats.h"

#define JNI_NATIVE(func) Java_org_fusesource_lmdbjni_JNI_##func

JNIEXPORT void JNICALL JNI_NATIVE(buffer_1copy__JJ_3BJJ)
	(JNIEnv *env, jclass that, jlong arg0, jlong arg1, jbyteArray arg2, jlong arg3, jlong arg4)
{
	jbyte *lparg2=NULL;
	JNI_NATIVE_ENTER(env, that, JNI_buffer_1copy__JJ_3BJJ_FUNC);
#ifdef JNI_VERSION_1_2
	if (IS_JNI_1_2) {
		if (arg2) if ((lparg2 = (*env)->GetPrimitiveArrayCritical(env, arg2, NULL)) == NULL) goto fail;
	} else
#endif
	{
		if (arg2) if ((lparg2 = (*env)->GetByteArrayElements(env, arg2, NULL)) == NULL) goto fail;
	}
	buffer_copy((const void *)(intptr_t)arg0, (size_t)arg1, (void *)lparg2, (size_t)arg3, (size_t)arg4);
fail:
#ifdef JNI_VERSION_1_2
	if (IS_JNI_1_2) {
		if (arg2 && lparg2) (*env)->ReleasePrimitiveArrayCritical(env, arg2, lparg2, 0);
	} else
#endif
	{
		if (arg2 && lparg2) (*env)->ReleaseByteArrayElements(env, arg2, lparg2, 0);
	}
	JNI_NATIVE_EXIT(env, that, JNI_buffer_1copy__JJ_3BJJ_FUNC);
}

JNIEXPORT void JNICALL JNI_NATIVE(buffer_1copy___3BJJJJ)
	(JNIEnv *env, jclass that, jbyteArray arg0, jlong arg1, jlong arg2, jlong arg3, jlong arg4)
{
	jbyte *lparg0=NULL;
	JNI_NATIVE_ENTER(env, that, JNI_buffer_1copy___3BJJJJ_FUNC);
#ifdef JNI_VERSION_1_2
	if (IS_JNI_1_2) {
		if (arg0) if ((lparg0 = (*env)->GetPrimitiveArrayCritical(env, arg0, NULL)) == NULL) goto fail;
	} else
#endif
	{
		if (arg0) if ((lparg0 = (*env)->GetByteArrayElements(env, arg0, NULL)) == NULL) goto fail;
	}
	buffer_copy((const void *)lparg0, (size_t)arg1, (void *)(intptr_t)arg2, (size_t)arg3, (size_t)arg4);
fail:
#ifdef JNI_VERSION_1_2
	if (IS_JNI_1_2) {
		if (arg0 && lparg0) (*env)->ReleasePrimitiveArrayCritical(env, arg0, lparg0, JNI_ABORT);
	} else
#endif
	{
		if (arg0 && lparg0) (*env)->ReleaseByteArrayElements(env, arg0, lparg0, JNI_ABORT);
	}
	JNI_NATIVE_EXIT(env, that, JNI_buffer_1copy___3BJJJJ_FUNC);
}

JNIEXPORT jint JNICALL JNI_NATIVE(errno)
	(JNIEnv *env, jclass that)
{
	jint rc = 0;
	JNI_NATIVE_ENTER(env, that, JNI_errno_FUNC);
	rc = (jint)errno;
	JNI_NATIVE_EXIT(env, that, JNI_errno_FUNC);
	return rc;
}

JNIEXPORT void JNICALL JNI_NATIVE(free)
	(JNIEnv *env, jclass that, jlong arg0)
{
	JNI_NATIVE_ENTER(env, that, JNI_free_FUNC);
	free((void *)(intptr_t)arg0);
	JNI_NATIVE_EXIT(env, that, JNI_free_FUNC);
}

JNIEXPORT void JNICALL JNI_NATIVE(init)(JNIEnv *env, jclass that)
{
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "MDB_VERSION_MAJOR", "I"), (jint)MDB_VERSION_MAJOR);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "MDB_VERSION_MINOR", "I"), (jint)MDB_VERSION_MINOR);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "MDB_VERSION_PATCH", "I"), (jint)MDB_VERSION_PATCH);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "MDB_VERSION_FULL", "I"), (jint)MDB_VERSION_FULL);
	(*env)->SetStaticLongField(env, that, (*env)->GetStaticFieldID(env, that, "MDB_VERSION_DATE", "J"), (jlong)(intptr_t)MDB_VERSION_DATE);
	(*env)->SetStaticLongField(env, that, (*env)->GetStaticFieldID(env, that, "MDB_VERSION_STRING", "J"), (jlong)(intptr_t)MDB_VERSION_STRING);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "MDB_FIXEDMAP", "I"), (jint)MDB_FIXEDMAP);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "MDB_NOSUBDIR", "I"), (jint)MDB_NOSUBDIR);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "MDB_NOSYNC", "I"), (jint)MDB_NOSYNC);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "MDB_RDONLY", "I"), (jint)MDB_RDONLY);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "MDB_NOMETASYNC", "I"), (jint)MDB_NOMETASYNC);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "MDB_WRITEMAP", "I"), (jint)MDB_WRITEMAP);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "MDB_MAPASYNC", "I"), (jint)MDB_MAPASYNC);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "MDB_NOTLS", "I"), (jint)MDB_NOTLS);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "MDB_NOLOCK", "I"), (jint)MDB_NOLOCK);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "MDB_NORDAHEAD", "I"), (jint)MDB_NORDAHEAD);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "MDB_NOMEMINIT", "I"), (jint)MDB_NOMEMINIT);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "MDB_REVERSEKEY", "I"), (jint)MDB_REVERSEKEY);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "MDB_DUPSORT", "I"), (jint)MDB_DUPSORT);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "MDB_INTEGERKEY", "I"), (jint)MDB_INTEGERKEY);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "MDB_DUPFIXED", "I"), (jint)MDB_DUPFIXED);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "MDB_INTEGERDUP", "I"), (jint)MDB_INTEGERDUP);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "MDB_REVERSEDUP", "I"), (jint)MDB_REVERSEDUP);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "MDB_CREATE", "I"), (jint)MDB_CREATE);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "MDB_NOOVERWRITE", "I"), (jint)MDB_NOOVERWRITE);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "MDB_NODUPDATA", "I"), (jint)MDB_NODUPDATA);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "MDB_CURRENT", "I"), (jint)MDB_CURRENT);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "MDB_RESERVE", "I"), (jint)MDB_RESERVE);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "MDB_APPEND", "I"), (jint)MDB_APPEND);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "MDB_APPENDDUP", "I"), (jint)MDB_APPENDDUP);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "MDB_MULTIPLE", "I"), (jint)MDB_MULTIPLE);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "MDB_FIRST", "I"), (jint)MDB_FIRST);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "MDB_FIRST_DUP", "I"), (jint)MDB_FIRST_DUP);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "MDB_GET_BOTH", "I"), (jint)MDB_GET_BOTH);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "MDB_GET_BOTH_RANGE", "I"), (jint)MDB_GET_BOTH_RANGE);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "MDB_GET_CURRENT", "I"), (jint)MDB_GET_CURRENT);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "MDB_GET_MULTIPLE", "I"), (jint)MDB_GET_MULTIPLE);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "MDB_LAST", "I"), (jint)MDB_LAST);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "MDB_LAST_DUP", "I"), (jint)MDB_LAST_DUP);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "MDB_NEXT", "I"), (jint)MDB_NEXT);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "MDB_NEXT_DUP", "I"), (jint)MDB_NEXT_DUP);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "MDB_NEXT_MULTIPLE", "I"), (jint)MDB_NEXT_MULTIPLE);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "MDB_NEXT_NODUP", "I"), (jint)MDB_NEXT_NODUP);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "MDB_PREV", "I"), (jint)MDB_PREV);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "MDB_PREV_DUP", "I"), (jint)MDB_PREV_DUP);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "MDB_PREV_NODUP", "I"), (jint)MDB_PREV_NODUP);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "MDB_SET", "I"), (jint)MDB_SET);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "MDB_SET_KEY", "I"), (jint)MDB_SET_KEY);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "MDB_SET_RANGE", "I"), (jint)MDB_SET_RANGE);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "MDB_SUCCESS", "I"), (jint)MDB_SUCCESS);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "MDB_KEYEXIST", "I"), (jint)MDB_KEYEXIST);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "MDB_NOTFOUND", "I"), (jint)MDB_NOTFOUND);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "MDB_PAGE_NOTFOUND", "I"), (jint)MDB_PAGE_NOTFOUND);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "MDB_CORRUPTED", "I"), (jint)MDB_CORRUPTED);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "MDB_PANIC", "I"), (jint)MDB_PANIC);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "MDB_VERSION_MISMATCH", "I"), (jint)MDB_VERSION_MISMATCH);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "MDB_INVALID", "I"), (jint)MDB_INVALID);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "MDB_MAP_FULL", "I"), (jint)MDB_MAP_FULL);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "MDB_DBS_FULL", "I"), (jint)MDB_DBS_FULL);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "MDB_READERS_FULL", "I"), (jint)MDB_READERS_FULL);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "MDB_TLS_FULL", "I"), (jint)MDB_TLS_FULL);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "MDB_TXN_FULL", "I"), (jint)MDB_TXN_FULL);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "MDB_CURSOR_FULL", "I"), (jint)MDB_CURSOR_FULL);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "MDB_PAGE_FULL", "I"), (jint)MDB_PAGE_FULL);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "MDB_MAP_RESIZED", "I"), (jint)MDB_MAP_RESIZED);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "MDB_INCOMPATIBLE", "I"), (jint)MDB_INCOMPATIBLE);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "MDB_BAD_RSLOT", "I"), (jint)MDB_BAD_RSLOT);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "MDB_BAD_TXN", "I"), (jint)MDB_BAD_TXN);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "MDB_BAD_VALSIZE", "I"), (jint)MDB_BAD_VALSIZE);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "MDB_BAD_DBI", "I"), (jint)MDB_BAD_DBI);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "MDB_LAST_ERRCODE", "I"), (jint)MDB_LAST_ERRCODE);
   return;
}
JNIEXPORT jlong JNICALL JNI_NATIVE(malloc)
	(JNIEnv *env, jclass that, jlong arg0)
{
	jlong rc = 0;
	JNI_NATIVE_ENTER(env, that, JNI_malloc_FUNC);
	rc = (intptr_t)(void *)malloc((size_t)arg0);
	JNI_NATIVE_EXIT(env, that, JNI_malloc_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL JNI_NATIVE(mdb_1cmp)
	(JNIEnv *env, jclass that, jlong arg0, jlong arg1, jobject arg2, jobject arg3)
{
	MDB_val _arg2, *lparg2=NULL;
	MDB_val _arg3, *lparg3=NULL;
	jint rc = 0;
	JNI_NATIVE_ENTER(env, that, JNI_mdb_1cmp_FUNC);
	if (arg2) if ((lparg2 = getMDB_valFields(env, arg2, &_arg2)) == NULL) goto fail;
	if (arg3) if ((lparg3 = getMDB_valFields(env, arg3, &_arg3)) == NULL) goto fail;
	rc = (jint)mdb_cmp((MDB_txn *)(intptr_t)arg0, (unsigned int)arg1, (MDB_val *)lparg2, (MDB_val *)lparg3);
fail:
	JNI_NATIVE_EXIT(env, that, JNI_mdb_1cmp_FUNC);
	return rc;
}

JNIEXPORT void JNICALL JNI_NATIVE(mdb_1cursor_1close)
	(JNIEnv *env, jclass that, jlong arg0)
{
	JNI_NATIVE_ENTER(env, that, JNI_mdb_1cursor_1close_FUNC);
	mdb_cursor_close((MDB_cursor *)(intptr_t)arg0);
	JNI_NATIVE_EXIT(env, that, JNI_mdb_1cursor_1close_FUNC);
}

JNIEXPORT jint JNICALL JNI_NATIVE(mdb_1cursor_1count)
	(JNIEnv *env, jclass that, jlong arg0, jlongArray arg1)
{
	jlong *lparg1=NULL;
	jint rc = 0;
	JNI_NATIVE_ENTER(env, that, JNI_mdb_1cursor_1count_FUNC);
	if (arg1) if ((lparg1 = (*env)->GetLongArrayElements(env, arg1, NULL)) == NULL) goto fail;
	rc = (jint)mdb_cursor_count((MDB_cursor *)(intptr_t)arg0, (size_t *)lparg1);
fail:
	if (arg1 && lparg1) (*env)->ReleaseLongArrayElements(env, arg1, lparg1, 0);
	JNI_NATIVE_EXIT(env, that, JNI_mdb_1cursor_1count_FUNC);
	return rc;
}

JNIEXPORT jlong JNICALL JNI_NATIVE(mdb_1cursor_1dbi)
	(JNIEnv *env, jclass that, jlong arg0)
{
	jlong rc = 0;
	JNI_NATIVE_ENTER(env, that, JNI_mdb_1cursor_1dbi_FUNC);
	rc = (unsigned int)mdb_cursor_dbi((MDB_cursor *)(intptr_t)arg0);
	JNI_NATIVE_EXIT(env, that, JNI_mdb_1cursor_1dbi_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL JNI_NATIVE(mdb_1cursor_1del)
	(JNIEnv *env, jclass that, jlong arg0, jint arg1)
{
	jint rc = 0;
	JNI_NATIVE_ENTER(env, that, JNI_mdb_1cursor_1del_FUNC);
	rc = (jint)mdb_cursor_del((MDB_cursor *)(intptr_t)arg0, (unsigned int)arg1);
	JNI_NATIVE_EXIT(env, that, JNI_mdb_1cursor_1del_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL JNI_NATIVE(mdb_1cursor_1get_1address)
	(JNIEnv *env, jclass that, jlong arg0, jlong arg1, jlong arg2, jint arg3)
{
	jint rc = 0;
	JNI_NATIVE_ENTER(env, that, JNI_mdb_1cursor_1get_1address_FUNC);
	rc = (jint)mdb_cursor_get((MDB_cursor *)(intptr_t)arg0, (MDB_val *)(intptr_t)arg1, (MDB_val *)(intptr_t)arg2, (MDB_cursor_op)arg3);
	JNI_NATIVE_EXIT(env, that, JNI_mdb_1cursor_1get_1address_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL JNI_NATIVE(mdb_1cursor_1get_1copy_1in)
	(JNIEnv *env, jclass that, jlong arg0, jobject arg1, jobject arg2, jint arg3)
{
	MDB_val _arg1, *lparg1=NULL;
	MDB_val _arg2, *lparg2=NULL;
	jint rc = 0;
	JNI_NATIVE_ENTER(env, that, JNI_mdb_1cursor_1get_1copy_1in_FUNC);
	if (arg1) if ((lparg1 = getMDB_valFields(env, arg1, &_arg1)) == NULL) goto fail;
	if (arg2) if ((lparg2 = getMDB_valFields(env, arg2, &_arg2)) == NULL) goto fail;
	rc = (jint)mdb_cursor_get((MDB_cursor *)(intptr_t)arg0, (MDB_val *)lparg1, (MDB_val *)lparg2, (MDB_cursor_op)arg3);
fail:
	if (arg2 && lparg2) setMDB_valFields(env, arg2, lparg2);
	if (arg1 && lparg1) setMDB_valFields(env, arg1, lparg1);
	JNI_NATIVE_EXIT(env, that, JNI_mdb_1cursor_1get_1copy_1in_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL JNI_NATIVE(mdb_1cursor_1get_1no_1copy_1in)
	(JNIEnv *env, jclass that, jlong arg0, jobject arg1, jobject arg2, jint arg3)
{
	MDB_val _arg1, *lparg1=NULL;
	MDB_val _arg2, *lparg2=NULL;
	jint rc = 0;
	JNI_NATIVE_ENTER(env, that, JNI_mdb_1cursor_1get_1no_1copy_1in_FUNC);
	if (arg1) if ((lparg1 = &_arg1) == NULL) goto fail;
	if (arg2) if ((lparg2 = &_arg2) == NULL) goto fail;
	rc = (jint)mdb_cursor_get((MDB_cursor *)(intptr_t)arg0, (MDB_val *)lparg1, (MDB_val *)lparg2, (MDB_cursor_op)arg3);
fail:
	if (arg2 && lparg2) setMDB_valFields(env, arg2, lparg2);
	if (arg1 && lparg1) setMDB_valFields(env, arg1, lparg1);
	JNI_NATIVE_EXIT(env, that, JNI_mdb_1cursor_1get_1no_1copy_1in_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL JNI_NATIVE(mdb_1cursor_1open)
	(JNIEnv *env, jclass that, jlong arg0, jlong arg1, jlongArray arg2)
{
	jlong *lparg2=NULL;
	jint rc = 0;
	JNI_NATIVE_ENTER(env, that, JNI_mdb_1cursor_1open_FUNC);
	if (arg2) if ((lparg2 = (*env)->GetLongArrayElements(env, arg2, NULL)) == NULL) goto fail;
	rc = (jint)mdb_cursor_open((MDB_txn *)(intptr_t)arg0, (unsigned int)arg1, (MDB_cursor **)lparg2);
fail:
	if (arg2 && lparg2) (*env)->ReleaseLongArrayElements(env, arg2, lparg2, 0);
	JNI_NATIVE_EXIT(env, that, JNI_mdb_1cursor_1open_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL JNI_NATIVE(mdb_1cursor_1put)
	(JNIEnv *env, jclass that, jlong arg0, jobject arg1, jobject arg2, jint arg3)
{
	MDB_val _arg1, *lparg1=NULL;
	MDB_val _arg2, *lparg2=NULL;
	jint rc = 0;
	JNI_NATIVE_ENTER(env, that, JNI_mdb_1cursor_1put_FUNC);
	if (arg1) if ((lparg1 = getMDB_valFields(env, arg1, &_arg1)) == NULL) goto fail;
	if (arg2) if ((lparg2 = getMDB_valFields(env, arg2, &_arg2)) == NULL) goto fail;
	rc = (jint)mdb_cursor_put((MDB_cursor *)(intptr_t)arg0, (MDB_val *)lparg1, (MDB_val *)lparg2, (unsigned int)arg3);
fail:
	JNI_NATIVE_EXIT(env, that, JNI_mdb_1cursor_1put_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL JNI_NATIVE(mdb_1cursor_1put_1address)
	(JNIEnv *env, jclass that, jlong arg0, jlong arg1, jlong arg2, jint arg3)
{
	jint rc = 0;
	JNI_NATIVE_ENTER(env, that, JNI_mdb_1cursor_1put_1address_FUNC);
	rc = (jint)mdb_cursor_put((MDB_cursor *)(intptr_t)arg0, (MDB_val *)(intptr_t)arg1, (MDB_val *)(intptr_t)arg2, (unsigned int)arg3);
	JNI_NATIVE_EXIT(env, that, JNI_mdb_1cursor_1put_1address_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL JNI_NATIVE(mdb_1cursor_1renew)
	(JNIEnv *env, jclass that, jlong arg0, jlong arg1)
{
	jint rc = 0;
	JNI_NATIVE_ENTER(env, that, JNI_mdb_1cursor_1renew_FUNC);
	rc = (jint)mdb_cursor_renew((MDB_txn *)(intptr_t)arg0, (MDB_cursor *)(intptr_t)arg1);
	JNI_NATIVE_EXIT(env, that, JNI_mdb_1cursor_1renew_FUNC);
	return rc;
}

JNIEXPORT jlong JNICALL JNI_NATIVE(mdb_1cursor_1txn)
	(JNIEnv *env, jclass that, jlong arg0)
{
	jlong rc = 0;
	JNI_NATIVE_ENTER(env, that, JNI_mdb_1cursor_1txn_FUNC);
	rc = (intptr_t)(MDB_txn *)mdb_cursor_txn((MDB_cursor *)(intptr_t)arg0);
	JNI_NATIVE_EXIT(env, that, JNI_mdb_1cursor_1txn_FUNC);
	return rc;
}

JNIEXPORT void JNICALL JNI_NATIVE(mdb_1dbi_1close)
	(JNIEnv *env, jclass that, jlong arg0, jlong arg1)
{
	JNI_NATIVE_ENTER(env, that, JNI_mdb_1dbi_1close_FUNC);
	mdb_dbi_close((MDB_env *)(intptr_t)arg0, (unsigned int)arg1);
	JNI_NATIVE_EXIT(env, that, JNI_mdb_1dbi_1close_FUNC);
}

JNIEXPORT jint JNICALL JNI_NATIVE(mdb_1dbi_1open)
	(JNIEnv *env, jclass that, jlong arg0, jstring arg1, jlong arg2, jlongArray arg3)
{
	const char *lparg1= NULL;
	jlong *lparg3=NULL;
	jint rc = 0;
	JNI_NATIVE_ENTER(env, that, JNI_mdb_1dbi_1open_FUNC);
	if (arg1) if ((lparg1 = (*env)->GetStringUTFChars(env, arg1, NULL)) == NULL) goto fail;
	if (arg3) if ((lparg3 = (*env)->GetLongArrayElements(env, arg3, NULL)) == NULL) goto fail;
	rc = (jint)mdb_dbi_open((MDB_txn *)(intptr_t)arg0, (const char *)lparg1, (unsigned int)arg2, (unsigned int *)lparg3);
fail:
	if (arg3 && lparg3) (*env)->ReleaseLongArrayElements(env, arg3, lparg3, 0);
	if (arg1 && lparg1) (*env)->ReleaseStringUTFChars(env, arg1, lparg1);
	JNI_NATIVE_EXIT(env, that, JNI_mdb_1dbi_1open_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL JNI_NATIVE(mdb_1dcmp)
	(JNIEnv *env, jclass that, jlong arg0, jlong arg1, jobject arg2, jobject arg3)
{
	MDB_val _arg2, *lparg2=NULL;
	MDB_val _arg3, *lparg3=NULL;
	jint rc = 0;
	JNI_NATIVE_ENTER(env, that, JNI_mdb_1dcmp_FUNC);
	if (arg2) if ((lparg2 = getMDB_valFields(env, arg2, &_arg2)) == NULL) goto fail;
	if (arg3) if ((lparg3 = getMDB_valFields(env, arg3, &_arg3)) == NULL) goto fail;
	rc = (jint)mdb_dcmp((MDB_txn *)(intptr_t)arg0, (unsigned int)arg1, (MDB_val *)lparg2, (MDB_val *)lparg3);
fail:
	JNI_NATIVE_EXIT(env, that, JNI_mdb_1dcmp_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL JNI_NATIVE(mdb_1del)
	(JNIEnv *env, jclass that, jlong arg0, jlong arg1, jobject arg2, jobject arg3)
{
	MDB_val _arg2, *lparg2=NULL;
	MDB_val _arg3, *lparg3=NULL;
	jint rc = 0;
	JNI_NATIVE_ENTER(env, that, JNI_mdb_1del_FUNC);
	if (arg2) if ((lparg2 = getMDB_valFields(env, arg2, &_arg2)) == NULL) goto fail;
	if (arg3) if ((lparg3 = getMDB_valFields(env, arg3, &_arg3)) == NULL) goto fail;
	rc = (jint)mdb_del((MDB_txn *)(intptr_t)arg0, (unsigned int)arg1, (MDB_val *)lparg2, (MDB_val *)lparg3);
fail:
	JNI_NATIVE_EXIT(env, that, JNI_mdb_1del_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL JNI_NATIVE(mdb_1drop)
	(JNIEnv *env, jclass that, jlong arg0, jlong arg1, jint arg2)
{
	jint rc = 0;
	JNI_NATIVE_ENTER(env, that, JNI_mdb_1drop_FUNC);
	rc = (jint)mdb_drop((MDB_txn *)(intptr_t)arg0, (unsigned int)arg1, arg2);
	JNI_NATIVE_EXIT(env, that, JNI_mdb_1drop_FUNC);
	return rc;
}

JNIEXPORT void JNICALL JNI_NATIVE(mdb_1env_1close)
	(JNIEnv *env, jclass that, jlong arg0)
{
	JNI_NATIVE_ENTER(env, that, JNI_mdb_1env_1close_FUNC);
	mdb_env_close((MDB_env *)(intptr_t)arg0);
	JNI_NATIVE_EXIT(env, that, JNI_mdb_1env_1close_FUNC);
}

JNIEXPORT jint JNICALL JNI_NATIVE(mdb_1env_1copy)
	(JNIEnv *env, jclass that, jlong arg0, jstring arg1)
{
	const char *lparg1= NULL;
	jint rc = 0;
	JNI_NATIVE_ENTER(env, that, JNI_mdb_1env_1copy_FUNC);
	if (arg1) if ((lparg1 = (*env)->GetStringUTFChars(env, arg1, NULL)) == NULL) goto fail;
	rc = (jint)mdb_env_copy((MDB_env *)(intptr_t)arg0, (const char *)lparg1);
fail:
	if (arg1 && lparg1) (*env)->ReleaseStringUTFChars(env, arg1, lparg1);
	JNI_NATIVE_EXIT(env, that, JNI_mdb_1env_1copy_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL JNI_NATIVE(mdb_1env_1copy2)
	(JNIEnv *env, jclass that, jlong arg0, jstring arg1, jint arg2)
{
	const char *lparg1= NULL;
	jint rc = 0;
	JNI_NATIVE_ENTER(env, that, JNI_mdb_1env_1copy2_FUNC);
	if (arg1) if ((lparg1 = (*env)->GetStringUTFChars(env, arg1, NULL)) == NULL) goto fail;
	rc = (jint)mdb_env_copy2((MDB_env *)(intptr_t)arg0, (const char *)lparg1, (unsigned int)arg2);
fail:
	if (arg1 && lparg1) (*env)->ReleaseStringUTFChars(env, arg1, lparg1);
	JNI_NATIVE_EXIT(env, that, JNI_mdb_1env_1copy2_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL JNI_NATIVE(mdb_1env_1create)
	(JNIEnv *env, jclass that, jlongArray arg0)
{
	jlong *lparg0=NULL;
	jint rc = 0;
	JNI_NATIVE_ENTER(env, that, JNI_mdb_1env_1create_FUNC);
	if (arg0) if ((lparg0 = (*env)->GetLongArrayElements(env, arg0, NULL)) == NULL) goto fail;
	rc = (jint)mdb_env_create((MDB_env **)lparg0);
fail:
	if (arg0 && lparg0) (*env)->ReleaseLongArrayElements(env, arg0, lparg0, 0);
	JNI_NATIVE_EXIT(env, that, JNI_mdb_1env_1create_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL JNI_NATIVE(mdb_1env_1get_1flags)
	(JNIEnv *env, jclass that, jlong arg0, jlongArray arg1)
{
	jlong *lparg1=NULL;
	jint rc = 0;
	JNI_NATIVE_ENTER(env, that, JNI_mdb_1env_1get_1flags_FUNC);
	if (arg1) if ((lparg1 = (*env)->GetLongArrayElements(env, arg1, NULL)) == NULL) goto fail;
	rc = (jint)mdb_env_get_flags((MDB_env *)(intptr_t)arg0, (unsigned int *)lparg1);
fail:
	if (arg1 && lparg1) (*env)->ReleaseLongArrayElements(env, arg1, lparg1, 0);
	JNI_NATIVE_EXIT(env, that, JNI_mdb_1env_1get_1flags_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL JNI_NATIVE(mdb_1env_1get_1maxkeysize)
	(JNIEnv *env, jclass that, jlong arg0)
{
	jint rc = 0;
	JNI_NATIVE_ENTER(env, that, JNI_mdb_1env_1get_1maxkeysize_FUNC);
	rc = (jint)mdb_env_get_maxkeysize((MDB_env *)(intptr_t)arg0);
	JNI_NATIVE_EXIT(env, that, JNI_mdb_1env_1get_1maxkeysize_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL JNI_NATIVE(mdb_1env_1get_1maxreaders)
	(JNIEnv *env, jclass that, jlong arg0, jlongArray arg1)
{
	jlong *lparg1=NULL;
	jint rc = 0;
	JNI_NATIVE_ENTER(env, that, JNI_mdb_1env_1get_1maxreaders_FUNC);
	if (arg1) if ((lparg1 = (*env)->GetLongArrayElements(env, arg1, NULL)) == NULL) goto fail;
	rc = (jint)mdb_env_get_maxreaders((MDB_env *)(intptr_t)arg0, (unsigned int *)lparg1);
fail:
	if (arg1 && lparg1) (*env)->ReleaseLongArrayElements(env, arg1, lparg1, 0);
	JNI_NATIVE_EXIT(env, that, JNI_mdb_1env_1get_1maxreaders_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL JNI_NATIVE(mdb_1env_1get_1path)
	(JNIEnv *env, jclass that, jlong arg0, jlongArray arg1)
{
	jlong *lparg1=NULL;
	jint rc = 0;
	JNI_NATIVE_ENTER(env, that, JNI_mdb_1env_1get_1path_FUNC);
	if (arg1) if ((lparg1 = (*env)->GetLongArrayElements(env, arg1, NULL)) == NULL) goto fail;
	rc = (jint)mdb_env_get_path((MDB_env *)(intptr_t)arg0, (const char **)lparg1);
fail:
	if (arg1 && lparg1) (*env)->ReleaseLongArrayElements(env, arg1, lparg1, 0);
	JNI_NATIVE_EXIT(env, that, JNI_mdb_1env_1get_1path_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL JNI_NATIVE(mdb_1env_1info)
	(JNIEnv *env, jclass that, jlong arg0, jobject arg1)
{
	MDB_envinfo _arg1, *lparg1=NULL;
	jint rc = 0;
	JNI_NATIVE_ENTER(env, that, JNI_mdb_1env_1info_FUNC);
	if (arg1) if ((lparg1 = &_arg1) == NULL) goto fail;
	rc = (jint)mdb_env_info((MDB_env *)(intptr_t)arg0, (MDB_envinfo *)lparg1);
fail:
	if (arg1 && lparg1) setMDB_envinfoFields(env, arg1, lparg1);
	JNI_NATIVE_EXIT(env, that, JNI_mdb_1env_1info_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL JNI_NATIVE(mdb_1env_1open)
	(JNIEnv *env, jclass that, jlong arg0, jstring arg1, jint arg2, jint arg3)
{
	const char *lparg1= NULL;
	jint rc = 0;
	JNI_NATIVE_ENTER(env, that, JNI_mdb_1env_1open_FUNC);
	if (arg1) if ((lparg1 = (*env)->GetStringUTFChars(env, arg1, NULL)) == NULL) goto fail;
	rc = (jint)mdb_env_open((MDB_env *)(intptr_t)arg0, (const char *)lparg1, (unsigned int)arg2, (mdb_mode_t)arg3);
fail:
	if (arg1 && lparg1) (*env)->ReleaseStringUTFChars(env, arg1, lparg1);
	JNI_NATIVE_EXIT(env, that, JNI_mdb_1env_1open_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL JNI_NATIVE(mdb_1env_1set_1flags)
	(JNIEnv *env, jclass that, jlong arg0, jint arg1, jint arg2)
{
	jint rc = 0;
	JNI_NATIVE_ENTER(env, that, JNI_mdb_1env_1set_1flags_FUNC);
	rc = (jint)mdb_env_set_flags((MDB_env *)(intptr_t)arg0, (unsigned int)arg1, (int)arg2);
	JNI_NATIVE_EXIT(env, that, JNI_mdb_1env_1set_1flags_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL JNI_NATIVE(mdb_1env_1set_1mapsize)
	(JNIEnv *env, jclass that, jlong arg0, jlong arg1)
{
	jint rc = 0;
	JNI_NATIVE_ENTER(env, that, JNI_mdb_1env_1set_1mapsize_FUNC);
	rc = (jint)mdb_env_set_mapsize((MDB_env *)(intptr_t)arg0, (size_t)arg1);
	JNI_NATIVE_EXIT(env, that, JNI_mdb_1env_1set_1mapsize_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL JNI_NATIVE(mdb_1env_1set_1maxdbs)
	(JNIEnv *env, jclass that, jlong arg0, jlong arg1)
{
	jint rc = 0;
	JNI_NATIVE_ENTER(env, that, JNI_mdb_1env_1set_1maxdbs_FUNC);
	rc = (jint)mdb_env_set_maxdbs((MDB_env *)(intptr_t)arg0, (unsigned int)arg1);
	JNI_NATIVE_EXIT(env, that, JNI_mdb_1env_1set_1maxdbs_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL JNI_NATIVE(mdb_1env_1set_1maxreaders)
	(JNIEnv *env, jclass that, jlong arg0, jlong arg1)
{
	jint rc = 0;
	JNI_NATIVE_ENTER(env, that, JNI_mdb_1env_1set_1maxreaders_FUNC);
	rc = (jint)mdb_env_set_maxreaders((MDB_env *)(intptr_t)arg0, (unsigned int)arg1);
	JNI_NATIVE_EXIT(env, that, JNI_mdb_1env_1set_1maxreaders_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL JNI_NATIVE(mdb_1env_1stat)
	(JNIEnv *env, jclass that, jlong arg0, jobject arg1)
{
	MDB_stat _arg1, *lparg1=NULL;
	jint rc = 0;
	JNI_NATIVE_ENTER(env, that, JNI_mdb_1env_1stat_FUNC);
	if (arg1) if ((lparg1 = &_arg1) == NULL) goto fail;
	rc = (jint)mdb_env_stat((MDB_env *)(intptr_t)arg0, (MDB_stat *)lparg1);
fail:
	if (arg1 && lparg1) setMDB_statFields(env, arg1, lparg1);
	JNI_NATIVE_EXIT(env, that, JNI_mdb_1env_1stat_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL JNI_NATIVE(mdb_1env_1sync)
	(JNIEnv *env, jclass that, jlong arg0, jint arg1)
{
	jint rc = 0;
	JNI_NATIVE_ENTER(env, that, JNI_mdb_1env_1sync_FUNC);
	rc = (jint)mdb_env_sync((MDB_env *)(intptr_t)arg0, (int)arg1);
	JNI_NATIVE_EXIT(env, that, JNI_mdb_1env_1sync_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL JNI_NATIVE(mdb_1get)
	(JNIEnv *env, jclass that, jlong arg0, jlong arg1, jobject arg2, jobject arg3)
{
	MDB_val _arg2, *lparg2=NULL;
	MDB_val _arg3, *lparg3=NULL;
	jint rc = 0;
	JNI_NATIVE_ENTER(env, that, JNI_mdb_1get_FUNC);
	if (arg2) if ((lparg2 = getMDB_valFields(env, arg2, &_arg2)) == NULL) goto fail;
	if (arg3) if ((lparg3 = &_arg3) == NULL) goto fail;
	rc = (jint)mdb_get((MDB_txn *)(intptr_t)arg0, (unsigned int)arg1, (MDB_val *)lparg2, (MDB_val *)lparg3);
fail:
	if (arg3 && lparg3) setMDB_valFields(env, arg3, lparg3);
	JNI_NATIVE_EXIT(env, that, JNI_mdb_1get_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL JNI_NATIVE(mdb_1get_1address)
	(JNIEnv *env, jclass that, jlong arg0, jlong arg1, jlong arg2, jlong arg3)
{
	jint rc = 0;
	JNI_NATIVE_ENTER(env, that, JNI_mdb_1get_1address_FUNC);
	rc = (jint)mdb_get((MDB_txn *)(intptr_t)arg0, (unsigned int)arg1, (MDB_val *)(intptr_t)arg2, (MDB_val *)(intptr_t)arg3);
	JNI_NATIVE_EXIT(env, that, JNI_mdb_1get_1address_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL JNI_NATIVE(mdb_1put)
	(JNIEnv *env, jclass that, jlong arg0, jlong arg1, jobject arg2, jobject arg3, jint arg4)
{
	MDB_val _arg2, *lparg2=NULL;
	MDB_val _arg3, *lparg3=NULL;
	jint rc = 0;
	JNI_NATIVE_ENTER(env, that, JNI_mdb_1put_FUNC);
	if (arg2) if ((lparg2 = getMDB_valFields(env, arg2, &_arg2)) == NULL) goto fail;
	if (arg3) if ((lparg3 = getMDB_valFields(env, arg3, &_arg3)) == NULL) goto fail;
	rc = (jint)mdb_put((MDB_txn *)(intptr_t)arg0, (unsigned int)arg1, (MDB_val *)lparg2, (MDB_val *)lparg3, (unsigned int)arg4);
fail:
	if (arg3 && lparg3) setMDB_valFields(env, arg3, lparg3);
	JNI_NATIVE_EXIT(env, that, JNI_mdb_1put_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL JNI_NATIVE(mdb_1put_1address)
	(JNIEnv *env, jclass that, jlong arg0, jlong arg1, jlong arg2, jlong arg3, jint arg4)
{
	jint rc = 0;
	JNI_NATIVE_ENTER(env, that, JNI_mdb_1put_1address_FUNC);
	rc = (jint)mdb_put((MDB_txn *)(intptr_t)arg0, (unsigned int)arg1, (MDB_val *)(intptr_t)arg2, (MDB_val *)(intptr_t)arg3, (unsigned int)arg4);
	JNI_NATIVE_EXIT(env, that, JNI_mdb_1put_1address_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL JNI_NATIVE(mdb_1reader_1check)
	(JNIEnv *env, jclass that, jlong arg0, jintArray arg1)
{
	jint *lparg1=NULL;
	jint rc = 0;
	JNI_NATIVE_ENTER(env, that, JNI_mdb_1reader_1check_FUNC);
	if (arg1) if ((lparg1 = (*env)->GetIntArrayElements(env, arg1, NULL)) == NULL) goto fail;
	rc = (jint)mdb_reader_check((MDB_env *)(intptr_t)arg0, (int *)lparg1);
fail:
	if (arg1 && lparg1) (*env)->ReleaseIntArrayElements(env, arg1, lparg1, 0);
	JNI_NATIVE_EXIT(env, that, JNI_mdb_1reader_1check_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL JNI_NATIVE(mdb_1set_1compare)
	(JNIEnv *env, jclass that, jlong arg0, jlong arg1, jlong arg2)
{
	jint rc = 0;
	JNI_NATIVE_ENTER(env, that, JNI_mdb_1set_1compare_FUNC);
	rc = (jint)mdb_set_compare((MDB_txn *)(intptr_t)arg0, (unsigned int)arg1, (MDB_cmp_func *)(intptr_t)arg2);
	JNI_NATIVE_EXIT(env, that, JNI_mdb_1set_1compare_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL JNI_NATIVE(mdb_1set_1dupsort)
	(JNIEnv *env, jclass that, jlong arg0, jlong arg1, jlong arg2)
{
	jint rc = 0;
	JNI_NATIVE_ENTER(env, that, JNI_mdb_1set_1dupsort_FUNC);
	rc = (jint)mdb_set_dupsort((MDB_txn *)(intptr_t)arg0, (unsigned int)arg1, (MDB_cmp_func *)(intptr_t)arg2);
	JNI_NATIVE_EXIT(env, that, JNI_mdb_1set_1dupsort_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL JNI_NATIVE(mdb_1stat)
	(JNIEnv *env, jclass that, jlong arg0, jlong arg1, jobject arg2)
{
	MDB_stat _arg2, *lparg2=NULL;
	jint rc = 0;
	JNI_NATIVE_ENTER(env, that, JNI_mdb_1stat_FUNC);
	if (arg2) if ((lparg2 = &_arg2) == NULL) goto fail;
	rc = (jint)mdb_stat((MDB_txn *)(intptr_t)arg0, (unsigned int)arg1, (MDB_stat *)lparg2);
fail:
	if (arg2 && lparg2) setMDB_statFields(env, arg2, lparg2);
	JNI_NATIVE_EXIT(env, that, JNI_mdb_1stat_FUNC);
	return rc;
}

JNIEXPORT jlong JNICALL JNI_NATIVE(mdb_1strerror)
	(JNIEnv *env, jclass that, jint arg0)
{
	jlong rc = 0;
	JNI_NATIVE_ENTER(env, that, JNI_mdb_1strerror_FUNC);
	rc = (intptr_t)(char *)mdb_strerror(arg0);
	JNI_NATIVE_EXIT(env, that, JNI_mdb_1strerror_FUNC);
	return rc;
}

JNIEXPORT void JNICALL JNI_NATIVE(mdb_1txn_1abort)
	(JNIEnv *env, jclass that, jlong arg0)
{
	JNI_NATIVE_ENTER(env, that, JNI_mdb_1txn_1abort_FUNC);
	mdb_txn_abort((MDB_txn *)(intptr_t)arg0);
	JNI_NATIVE_EXIT(env, that, JNI_mdb_1txn_1abort_FUNC);
}

JNIEXPORT jint JNICALL JNI_NATIVE(mdb_1txn_1begin)
	(JNIEnv *env, jclass that, jlong arg0, jlong arg1, jlong arg2, jlongArray arg3)
{
	jlong *lparg3=NULL;
	jint rc = 0;
	JNI_NATIVE_ENTER(env, that, JNI_mdb_1txn_1begin_FUNC);
	if (arg3) if ((lparg3 = (*env)->GetLongArrayElements(env, arg3, NULL)) == NULL) goto fail;
	rc = (jint)mdb_txn_begin((MDB_env *)(intptr_t)arg0, (MDB_txn *)(intptr_t)arg1, (unsigned int)arg2, (MDB_txn **)lparg3);
fail:
	if (arg3 && lparg3) (*env)->ReleaseLongArrayElements(env, arg3, lparg3, 0);
	JNI_NATIVE_EXIT(env, that, JNI_mdb_1txn_1begin_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL JNI_NATIVE(mdb_1txn_1commit)
	(JNIEnv *env, jclass that, jlong arg0)
{
	jint rc = 0;
	JNI_NATIVE_ENTER(env, that, JNI_mdb_1txn_1commit_FUNC);
	rc = (jint)mdb_txn_commit((MDB_txn *)(intptr_t)arg0);
	JNI_NATIVE_EXIT(env, that, JNI_mdb_1txn_1commit_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL JNI_NATIVE(mdb_1txn_1id)
	(JNIEnv *env, jclass that, jlong arg0)
{
	jint rc = 0;
	JNI_NATIVE_ENTER(env, that, JNI_mdb_1txn_1id_FUNC);
	rc = (jint)mdb_txn_id((MDB_txn *)(intptr_t)arg0);
	JNI_NATIVE_EXIT(env, that, JNI_mdb_1txn_1id_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL JNI_NATIVE(mdb_1txn_1renew)
	(JNIEnv *env, jclass that, jlong arg0)
{
	jint rc = 0;
	JNI_NATIVE_ENTER(env, that, JNI_mdb_1txn_1renew_FUNC);
	rc = (jint)mdb_txn_renew((MDB_txn *)(intptr_t)arg0);
	JNI_NATIVE_EXIT(env, that, JNI_mdb_1txn_1renew_FUNC);
	return rc;
}

JNIEXPORT void JNICALL JNI_NATIVE(mdb_1txn_1reset)
	(JNIEnv *env, jclass that, jlong arg0)
{
	JNI_NATIVE_ENTER(env, that, JNI_mdb_1txn_1reset_FUNC);
	mdb_txn_reset((MDB_txn *)(intptr_t)arg0);
	JNI_NATIVE_EXIT(env, that, JNI_mdb_1txn_1reset_FUNC);
}

JNIEXPORT jlong JNICALL JNI_NATIVE(strerror)
	(JNIEnv *env, jclass that, jint arg0)
{
	jlong rc = 0;
	JNI_NATIVE_ENTER(env, that, JNI_strerror_FUNC);
	rc = (intptr_t)(char *)strerror(arg0);
	JNI_NATIVE_EXIT(env, that, JNI_strerror_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL JNI_NATIVE(strlen)
	(JNIEnv *env, jclass that, jlong arg0)
{
	jint rc = 0;
	JNI_NATIVE_ENTER(env, that, JNI_strlen_FUNC);
	rc = (jint)strlen((const char *)(intptr_t)arg0);
	JNI_NATIVE_EXIT(env, that, JNI_strlen_FUNC);
	return rc;
}

